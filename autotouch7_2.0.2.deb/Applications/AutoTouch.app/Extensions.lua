function tap(x, y)
    touchDown(0, x, y);
    usleep(16000);
    touchUp(0, x, y);
end


-- color: the color to find
-- count: 0 means all, 1 means first, 2 means first and second
function findColorTap(rgb, count)
    local result = findColor(rgb, count);
    if result ~= nil then
        for i, v in pairs(result) do
            tap(v[1], v[2]);
            usleep(16000);
        end
    end
end


--imagePath: the image to find. (REQUIRED)
--count: 0 means all, 1 means first, 2 means first and second. (OPTIONAL).
--fuzzy: the degree of fuzzy matching when finding, default is 1, means match exactly, fuzzy=0.5 means match 50%. (OPTIONAL)
--ignoreColors: array(table in lua) type of colors will be ignored when finding. (OPTIONAL).
function findImageTap(args)
    local result = findImage {imagePath=args.imagePath, count=args.count, fuzzy=args.fuzzy, ignoreColors=args.ignoreColors};
    if result ~= nil then
        for i, v in pairs(result) do
            tap(v[1], v[2]);
            usleep(16000);
        end
    end
end