To change colors, language
date and/or 12hr/24hr format,
open SETUP.js and follow 
the instructions.

Hugs 'n kisses,
ImLemonPartying


Theme based on:
Matrix by /u/arthurdapaz
and LS Chr0nos by ChrisGraphiX.