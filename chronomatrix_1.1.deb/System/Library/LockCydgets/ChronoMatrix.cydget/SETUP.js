//  Configuration brought to you
//  by ImLemonPartying
//  Hugs 'n kisses!
//
//
//  Change theme color here.
//
//  Blue = 1
//  Cyan = 2
//  Green = 3
//  Orange = 4
//  Purple = 5
//  Red = 6
//  White = 7
//  Yellow = 8
//
//  For example, to change to Red:
//  var theme = "6";
var theme = "2";
//
//
//
//  Change time format here.
//
//  12-hour = true
//  24-hr = false
//
//  For example, to change to 24-hr
//  var makeit12hr = false;
var makeit12hr = true;
//
//
//
//  Change date format here.
//
//  dd/mm/yy = true
//  mm/dd/yy = false
var EuroDate = false;
//
//
//
//  Change language here.
//
//  EN = English
//  SP = Spanish
//  FR = French
//  DE = German 
//  IT  =Italian 
//  NL = Dutch 
//  TR = Turkish
var lang = "EN";