//
//
// dont change anything below this line 
// unless you know what you are doing :-)
//
//
if (theme==1) {
	themeColor = 'blue';
	}
if (theme==2) {
	themeColor = 'cyan';
	}
if (theme==3) {
	themeColor = 'green';
	}
if (theme==4) {
	themeColor = 'orange';
	}
if (theme==5) {
	themeColor = 'purple';
	}
if (theme==6) {
	themeColor = 'red';
	}
if (theme==7) {
	themeColor = 'white';
	}
if (theme==8) {
	themeColor = 'yellow';
	}
else if (theme<=0 || theme>=9) {
	themeColor = 'green';
	}