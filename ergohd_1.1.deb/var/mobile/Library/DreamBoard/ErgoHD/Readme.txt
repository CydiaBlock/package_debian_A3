Welcome to ErgoHD - The New Interface - Release 1.1

Thank you for your Donation to this theme.

Please come and join us on the forum at ModMyi. All updates, bug reports, enhancement request should be posted there.

Link is: http://modmyi.com/forums/iphone-4-new-skins-themes-launches/765401-preview-ergohd-new-interface.html

Thanks to:

WyndWarrior for DreamBoard and original weather widget.
PhanaticD, PathKiller29, fallenzx for tests and feedbacks
Genusa for support and feedback

Credits:
Wyndwarrior for original Weather Widgets. Thanks for letting me modify it and use it.

Icons Credits (used according to their required license):
Safari icon: Photoshopedia - http://www.photoshopedia.com/
WeatherSetting icon:  http://www.icons-land.com
All other icons: Alessandro Rei - Dark Glass icons - http://www.kde-look.org/usermanager/search.php?username=mentalrey

I added the round and glow effect to them.

Finally Thanks to all of you for this great community. 



Usage:

- You need to use the dotted scroller to scroll the icons

- In a few rare cases you have to double-tap an icon for it to launch, I am investigating.


C ya online.




The Warlu


