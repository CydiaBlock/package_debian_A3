###############################################
#            DEBRepacker v0.1 beta            #
#              Created by Fabius              #
#               4th August 2011               #
#         Follow me on twitter @fab1us        #
###############################################

#################
# WHAT IS THIS? #
#################

This is a DEB repacking tool meant to make repo managers' life easier.
This is a console package, not a tweak nor an app. You'll have to run a command via MobileTerminal or better via SSH.
Why to use this instead of your tiny shiny PHP repacker?
Because this tool lets you repack the DEBs keeping that damn 4 digits permissions (7777 and so on) and also proper Group (wheel, mobile, etc.) and Owner (root, mobile, etc.).
This script can be run on Linux and Mac too (if you have required side packages) but it could badly set permissions/group/owner.
So my suggestion is to run it only on iPhoneOS systems.
The usage of this tool requires some basic knowlegdes that i'm not going to teach you.
If you still dont know what we're talking about, just close this readme and trash this package.

#################
# HOW IT WORKS? #
#################

This is the syntax of the command you'll have to run:

repack [[/path/]inputfile.deb [-O [[/path/]outputfile.deb]] | -A [/path/inputdir/] [-D [/path/outputdir/]]] [[-P [[/path/]Packages[.gz|.bz2]]] [-F [debsfolder]] [-H [msh]]] [-X] [-W [[/path/]pkglog.txt]]
       [-a [Author]] [-b [Pre-Depends]] [-c [Depiction]] [-d [Depends]] [-e [dev]] [-f [Conflicts]] [-g [Provides]] [-h [Homepage]] [-i [Icon]] [-l [Replaces]] [-m [Maintainer]]
       [-n [Name]] [-o [Sponsor]] [-p [Package]] [-r [Description]] [-s [Section]] [-t [Tag]] [-u [Architecture]] [-v [Version]] [-y [Priority]] [-z [Installed-Size]]

And here follows a little explanation of each parameter, with examples:

repack --help            shows command syntax
repack --version         shows repack version

inputfile.deb > input DEB to be repacked. It's possible to specify a /path/to/inputfile.deb or simply use inputfile.deb if it's placed in current working folder.
-O > change output DEB name. If not specified, or if you do not provide a value for this, Package ID and Version of output DEB will be used as output DEB name, example: "com.myrepo.myapp_1.0_iphoneos-arm.deb"
     It's possible to specify a /path/to/outputfile.deb or simply use outputfile.deb to place it in current working folder.
-A > repack all DEBs in a folder. If you do not provide a value for this, current working folder will be used as input folder.
-D > change output folder when repacking all DEBs of a folder. If not specified, or if you do not provide a value for this, current working folder will be used as output folder.
     Package ID and Version of output DEBs will be used as output DEB name, example: "com.myrepo.myapp_1.0_iphoneos-arm.deb").
-P > creates or updates a Packages file (plain text or gzip compressed or bzip2 compressed) for your repo with the new control files of repacked DEBs.
     If you do not provide a value for this, a plain text Packages file will be created (or updated if file exists) in current working directory.
-F > specifies the folder where debs will be hosted on your repo, to be written on Packages file, exampe: "debs" if your debs are under http://www.example.com/repo/debs/
     If you do not provide a vlue for this, "debs" will be used as folder when writing on Packages file.
-H > specifies the hashsum of the DEB, to be written on Packages file, exampe: "msh" (m = md5 | s = sha1 | h = sha256)
     You can choose to write one, two or all three hashsums. If you do not provide a vlue for this only md5 hash will be written.
-X > delete original DEB after repacking.
-W > generate a text file containing a log of the control files of all repacked DEBs
     If no file name is specified nor a default value is set, pkglog.txt in current working folder will be used.
-a > change "Author" parameter value, example: "Fabius <fabius@fabius.fab>"
-b > change "Pre-Depends" parameter value, example: "com.fabius.myappdepend"
-c > change "Depiction" parameter value, example: "http://www.example.com/MyAppDepiction.php"
-d > change "Depends" parameter value, example: "mobilesubstrate (>= 0.9.2587-1), libstatusbar | firmware (<< 4.0)"
-e > change "dev" parameter value, example: "fabius"
-f > change "Conflicts" parameter value, example: "com.fabius.badapp, com.fabius.anotherbadapp"
-g > change "Provides" parameter value, example: "myapp"
-h > change "Homepage" parameter value, example: "http://www.example.com/MyApp.php"
-i > change "Icon" parameter value, example: "file:///Applications/MyApp.app/icon.png"
-l > change "Replaces" parameter value, example: "com.fabius.oldapp"
-m > change "Maintainer" parameter value, example: "Fabius <fabius@fabius.fab>"
-n > change "Name" parameter value, example: "My App"
-o > change "Sponsor" parameter value, example: "Fabius <http://twitter.com/fab1us>"
-p > change "Package" parameter value, example: "com.myrepo" (NO DOT AT THE END! It will be automatically added to result like: com.myrepo.myapp)
     This parameter cannot be removed from control file as it's necessary. If you try to blank it, original value will be used.
-r > change "Description" parameter value, example: "This is my app!"
-s > change "Section" parameter value, example: "Fabius Apps"
-t > change "Tag" parameter value, example: "purpose::extension, cydia::commercial"
-u > change "Architecture" parameter value, example: "iphoneos-arm"
-v > change "Version" parameter value, example: "1.0"
     This parameter cannot be removed from control file as it's necessary. If you try to blank it, original value will be used.
-y > change "Priority" parameter value, example: "optional"
-z > change "Installed-Size" parameter value (number in Bytes), example: "12345"

IMPORTANT! Enclose parameter's values into quotes (i.e.: "value"), especially if they contain spaces (i.e.: "value with spaces")!

If you do not use a certain flag, no change will be performed to it's relative parameter in the output DEBs control file.
If you use certain a flag and specify a value for it, changes will be done to it's relative parameter in the output DEBs control file.
If you use certain a flag and specify a blank value for it "" (no value between quotes) the parameter will be removed in the output DEBs control file.
The following parameters CANNOT BE REMOVED as they are necessary fields of a control file (if you try to blank them with "" original values will be used):
Package, Version

Also please note that -P and -W flags have different purposes. -P flag is used to create/updated Packages file, which is a file necessary for your repo to work.
It contains the full list of control files, plus some other infos on their relative DEBs (such as file URL, file size and hashsum).

NOTE ABOUT SOME POSSIBLE ERRORS:
If you get errors like:

-sh: !": event not found

or

-sh: ./command: /bin/bash^M: bad interpreter: No such file or directory

It simply means that you're running a tooooo looooong command.
You'll need to split it like
repack old.deb new.deb -someflags
repack new.deb very.deb -someotherflags

##################
# HOW TO CONFIG? #
##################

This tool can be configured.
To do so you'll need to open "/bin/repack" file with a text editor and scroll down 'till you find the CONFIG section.
Make the changes you need and save the file.
You can set a default value for almost any parameter so that when launching repack command on a DEB with a certain flag, if you dont specify a value for that flag, the default value will be used.
For example if you specify "Fabius" as default "Mantainer" and run:
> repack -m myfile.deb
the DEB will be repacked with "Fabius" as "Mantainer" even if you did not run:
> repack -m myfile.deb "Fabius"
If you specify a different value from the default one it will be used in the place of it. So if you
specify "Fabius" as default "Mantainer" but you run:
> repack -m myfile.deb "Suibaf"
"Suibaf" will be set as the "Mantainer" for the DEB you repacked.
A particular attention must be given to "Package" value: it is obvious that this parameter cannot have a completely constant value.
If you specify a default value for this field it will be used as first part of the "Package" ID.
For example if you specify "com.fabius" as default value, and the original DEB has "net.suibaf.myfile" as "Package" ID, the repacked DEB will have a "Package" ID like "com.fabius.myfile".
If the original DEB has "myotherfile" (no dots) as "Package" ID, the repacked DEB will have a "Package" ID like "com.fabius.myotherfile".

######################
# HAVE REQUIREMENTS? #
######################

Yes, this tool requires you to have some other bash tools installed to work properly.
Most of them are preinstalled on any jailbroken device but some, like "sed" are not.
Here i provide a full list (alphabetical order) of the commands used.
If you dont have the relative binaries in /bin/ or in /usr/bin/ folder, you'll need to download them via Cydia.

basename
bzip2
cat
chmod
chown
dirname
dpkg
echo
gzip
md5sum
mkdir
mv
read
rm
sed
sha1sum
sha256sum
stat
tr

##############
# LAST NOTES #
##############

If you feel you found a bug, or wanna ask for more features/improvements, or just wanna say thanks, you can contact me on Twitter @fab1us [ http://twitter.com/fab1us ]

#############
# CHANGELOG #
#############

- 0.1beta
First public beta (may have bugs)
