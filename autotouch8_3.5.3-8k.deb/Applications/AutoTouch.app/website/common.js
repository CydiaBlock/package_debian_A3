function loadFiles() {
	var filePath = getCurrentPath();
	var url = '/files?path=' + encodeURIComponent(filePath);
	httpRequest(url, 'GET', null, success);

	function success(responseText) {
		var respObj = JSON.parse(responseText);

		var html = '';
		respObj.files.forEach(function(value, index){
			var filePath = value.filePath;
			var fileSize = value.fileSize;
			var iconName = value.iconName;
			var fileName = getFilename(filePath);
			var fileNameLink;
			if (isFolder(iconName)) {
				fileNameLink = '/?path=' + encodeURIComponent(filePath);
			} else if (isImage(iconName)) {
				fileNameLink = '/file/view?path=' + encodeURIComponent(filePath);
			} else {
				fileNameLink = '/file/edit?path=' + encodeURIComponent(filePath);
			}
			html += '<tr><td><img src="/icons/' + iconName + '">';
			if (isFolder(iconName)) {
				html += '<a href="' + fileNameLink + '">' + fileName + '</a></td>';
			} else {
				html += '<a href="' + fileNameLink + '" target="_blank">' + fileName + '</a></td>';
			}
			html += '<td>' + fileSize + '</td>'
			html += '<td>';
			if (isFolder(iconName)) {
				html += '&nbsp;&nbsp;&nbsp;&nbsp;';
			} else if (isImage(iconName)) {
				html += '<a href="' + fileNameLink + '" target="_blank">View</a>';
			} else {
				html += '<a href="' + fileNameLink + '" target="_blank">Edit</a>';
			}

			html += '<a href="#" onclick="deleteFile(\'' + filePath + '\');return false;">Delete</a>'
			+'<a href="#" onclick="renameFile(\'' + filePath + '\');return false;">Rename</a>'
			+'</td></tr>';
		});
		document.getElementById("fileList").innerHTML = html;
	}
}

function newFile() {
	var filename = prompt("Please input the filename","");
	if(filename) {
		var filePath = getCurrentPath();
		var newFilePath = filePath + '/' + filename;
		askServerToNewFile(newFilePath);
	}

	function askServerToNewFile(filePath) {
		var url = '/file/new?path=' + encodeURIComponent(filePath);
		httpRequest(url, 'GET', null, success);

		function success(responseText) {
			var respObj = JSON.parse(responseText);
			if (respObj.status == 'success') {
				loadFiles();
			} else {
				alert(respObj.info);
			}
		}
	}
}

function newFolder() {
	var filename = prompt("Please input the folder name","");
	if(filename) {
		var filePath = getCurrentPath();
		var newFilePath = filePath + '/' + filename;
		askServerToNewFile(newFilePath);
	}

	function askServerToNewFile(filePath) {
		var url = '/file/newFolder?path=' + encodeURIComponent(filePath);
		httpRequest(url, 'GET', null, success);

		function success(responseText) {
			var respObj = JSON.parse(responseText);
			if (respObj.status == 'success') {
				loadFiles();
			} else {
				alert(respObj.info);
			}
		}
	}
}

function saveFile() {
	var filePath = getCurrentPath();
	var content = editor.getValue();

	var url = '/file/update?path=' + encodeURIComponent(filePath);
	var params = 'content=' + encodeURIComponent(content);

	httpRequest(url, 'POST', params, success);

	function success(responseText) {
		var respObj = JSON.parse(responseText);
		if (respObj.status == 'success') {
			showSavedLabel();
		} else {
			alert(respObj.info);
		}
	}

	function showSavedLabel() {
		document.getElementById("saved").style.display = 'block';
		setTimeout(hideSavedLabel, 500);
	}

	function hideSavedLabel() {
		document.getElementById("saved").style.display = 'none';
	}
}

function renameFile(oldFilePath) {
	var newFilename = prompt("Please input the new filename","");
	if(newFilename) {
		var filePath = getCurrentPath();
		var newFilePath = filePath + '/' + newFilename;
		askServerToRenameFile(oldFilePath, newFilePath);
	}

	function askServerToRenameFile(oldFilePath, newFilePath) {
		var url = '/file/rename?path=' + encodeURIComponent(oldFilePath) + '&newPath=' + encodeURIComponent(newFilePath);
		httpRequest(url, 'GET', null, success);

		function success(responseText) {
			var respObj = JSON.parse(responseText);
			if (respObj.status == 'success') {
				loadFiles();
			} else {
				alert(respObj.info);
			}
		}
	}
}

function deleteFile(filePath) {
	if(confirm("Are you sure to delete the file?")) {
		var url = '/file/delete?path=' + encodeURIComponent(filePath);
		httpRequest(url, 'GET', null, success);

		function success(responseText) {
			var respObj = JSON.parse(responseText);
			if (respObj.status == 'success') {
				loadFiles();
			} else {
				alert(respObj.info);
			}
		}
	}
}

function uploadFile() {
    var file = document.getElementById("file").files[0];
    if (file) {
    	var filePath = getCurrentPath() + '/' + file.name;
	    var action = '/file/upload?path=' + encodeURIComponent(filePath);
	    var uploadForm = document.getElementById('uploadForm');
	    uploadForm.action = action;
	    uploadForm.submit();
    };
}

function httpRequest(url, method, params, success) {
	var httpRequest;
    if (window.XMLHttpRequest) { // Mozilla, Safari, ...
    	httpRequest = new XMLHttpRequest();
    } else if (window.ActiveXObject) { // IE
    	try {
    		httpRequest = new ActiveXObject("Msxml2.XMLHTTP");
    	} catch (e) {
    		try {
    			httpRequest = new ActiveXObject("Microsoft.XMLHTTP");
    		} catch (e) {
    			alert('Caught Exception: ' + e.message);
    		}
    	}
    }

    if (!httpRequest) {
		alert('Giving up :( Cannot create an XMLHTTP instance');
		return;
	}
	httpRequest.onreadystatechange = function() {
		try {
			if (httpRequest.readyState === 4) {
				if (httpRequest.status === 200) {
					success(httpRequest.responseText);
				} else {
					alert('There was a problem with the request.Request status: ' + httpRequest.statusText);
				}
			}
		} catch(e) {
			alert('Caught Exception: ' + e.message);
		}
	};
	httpRequest.open(method, url, true);
	if (method == 'GET') {
		httpRequest.send(null);
	} else if (method == 'POST') {
		httpRequest.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
		httpRequest.send(params);
	}
}

function getFilename(filePath) {
	var elements = filePath.split('/');
	return elements[elements.length - 1];
}

function getCurrentPath() {
	var search = window.location.search;
	if (search.length > 2) {
		search = search.substring(1, search.length);
		var keyValueStrList = search.split('&');
		for (var i = 0; i < keyValueStrList.length; i++) {
			var keyValue = keyValueStrList[i].split('=');
			if (keyValue[0] == 'path') {
				return decodeURIComponent(keyValue[1]);
			};
		};
	};
	return '/';
}

function isFolder(iconName) {
	return iconName.indexOf('folder') === 0;
}

function isImage(iconName) {
	return iconName.indexOf('bmp') === 0;
}

function makeBreadcrumb() {
	var filePath = getCurrentPath();
	var pathElems = filePath.split('/');
	var html = '';
	var path = '';
	for (var i = 0; i< pathElems.length; i++) {
		if (i == 0) {
			path = '/';
		} else if (i == 1) {
			path += pathElems[i];
		} else {
			path += '/' + pathElems[i];
		}

		if (i == 0) {
			html += '<li><a href="/?path='+ encodeURIComponent(path) +'">Home</a></li>';
		} else if (i == pathElems.length - 1) {
			html += '<li class="active">' + pathElems[i] + '</li>';
		} else {
			html += '<li><a href="/?path='+ encodeURIComponent(path) +'">' + pathElems[i] + '</a></li>';
		}
	};
	document.getElementById('breadcrumb').innerHTML = html;
}