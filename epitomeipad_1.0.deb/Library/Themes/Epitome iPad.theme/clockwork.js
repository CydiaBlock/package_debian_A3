function init2 ( )

{

  timeDisplay = document.createTextNode ( "" );

  document.getElementById("weekday").appendChild ( timeDisplay );

  document.getElementById("month").appendChild ( timeDisplay );

  document.getElementById("season").appendChild ( timeDisplay );
  
  document.getElementById("season1").appendChild ( timeDisplay );

}

function calendarDate ( )

{

/* Change the strings for the weekdays correnspondingly, only leave one of the strings uncommented */
/*   var this_weekday_name_array = new Array("Sunday","Monday","tuesday","Wednesday","Thursday","Friday","Saturday") */
/*   var this_weekday_name_array = new Array("Dimanche","Lundi","Mardi","Mercredi","Jeudi","Vendredi","Samedi") */
var this_weekday_name_array = new Array("Sunday","monday","tuesday","Wednesday","Thursday","Friday","Saturday") /* my own potentially lame weekday name strings :p */

/* the same applies to the month strings too */
/*   var this_month_name_array = new Array("Janvier","F�vrier","Mars","Avril","Mai","Juin","Juillet","Ao�t","Septembre","Octobre","Novembre","D�cembre") */
  var this_month_name_array = new Array("January","February","March","April","May","June","July","August","September","October","November","December")

/* the seasons can also be changed corresponding to the months starting from january depending on where you live (which hemisphere) */
/*   var this_season_name_array = new Array("hiver","hiver","printemps","printemps","printemps","�t�","�t�","�t�","automne","automne","automne","hiver") */
  var this_season_name_array = new Array("Winter","Winter","Spring","Spring","Spring","Summer","Summer","summer","Autumn","Autumn","Autumn","Winter")
    
  var this_date_timestamp = new Date()	  

  var this_weekday = this_date_timestamp.getDay()    

  var this_month = this_date_timestamp.getMonth()

  var this_season = this_date_timestamp.getMonth()
  
  document.getElementById("weekday").firstChild.nodeValue = this_weekday_name_array[this_weekday];

  document.getElementById("month").firstChild.nodeValue = this_month_name_array[this_month];

  document.getElementById("season").firstChild.nodeValue = this_season_name_array[this_season];
  
  document.getElementById("season1").firstChild.nodeValue = this_season_name_array[this_season];

}