/*

Configuration here

by ImLemonPartying

*/

	// AFTER MAKING ANY CHANGES HERE, RESPRING YOUR DEVICE!
	

 	// 12 Hour Code (change to false for 24Hour) 
	var Make_It_12_Hour = true;


	// AFTER MAKING ANY CHANGES HERE, RESPRING YOUR DEVICE!

/*

Hugs 'n kisses,
ImLemonPartying

*/
