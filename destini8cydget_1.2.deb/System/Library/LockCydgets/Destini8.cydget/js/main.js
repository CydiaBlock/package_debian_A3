var currentDay = 0;
var DG = "&deg;";
var KPH = settingsObject.kph;
var TwentyFour = settingsObject.twentyfour;
var PadZero = settingsObject.padzero;
var temp = settingsObject.celsius;
var RI=60000*Math.round(settingsObject.refresh); //refresh interval set to 15mins
var CT = new Date().getTime();

var days = ['day1', 'day2', 'day3','day4','day5'];

var getEL = function(el){
	return document.getElementById(el);
};

getEL('today').innerHTML=today;

getStyle = function(oElm, strCssRule){
	var strValue = "";
	if(document.defaultView && document.defaultView.getComputedStyle){
		strValue = document.defaultView.getComputedStyle(oElm, "").getPropertyValue(strCssRule);
	}
	else if(oElm.currentStyle){
		strCssRule = strCssRule.replace(/\-(\w)/g, function (strMatch, p1){
			return p1.toUpperCase();
		});
		strValue = oElm.currentStyle[strCssRule];
	}
	return strValue;
};

var showlow = function(){
	if(getEL('lo').style.display === "none"){
		getEL('feel').style.display = "none";
		getEL('lo').style.display = "block";
	}
	else{
		getEL('feel').style.display = "block";
		getEL('lo').style.display = "none";
	}
};
var weatherdetails = function(){
    document.getElementById('details').style.display = "block";
    document.getElementById('weathericon').style.display = "none";
};

var detailsoff = function(){
    document.getElementById('details').style.display = "none";
    document.getElementById('weathericon').style.display = "block";
};

var clearClasses = function() {
    d = document.getElementById(days[currentDay]);
    d.className = d.className.replace(" moveRight", "");
    d.className = d.className.replace(" moveLeft", "");
    d.className = d.className.replace(" moveOutLeft", "");
    d.className = d.className.replace(" moveOutRight", "");
};

var next = function() {
    playsound('next');
    if(getEL('details').style.display === "block"){
        detailsoff();
    }
    if (days[currentDay] !== "day5") {
        if (days[currentDay] === "day4") {
            getEL('nextday').style.opacity = 0;
        }
        clearClasses();
        el = getEL(days[currentDay]);
        el.className += el.className ? ' moveOutLeft' : 'moveOutLeft';
        currentDay += 1;
        el2 = getEL(days[currentDay]);
        el2.className += el2.className ? ' moveLeft' : 'moveLeft';
    }
};

var prev = function() {
    playsound('next');
    if(getEL('details').style.display === "block"){
        detailsoff();
    }
    if (days[currentDay] !== "day1") {
        if (getStyle(getEL("nextday"), "opacity")) {
            getEL('nextday').style.opacity = 1;
        }
        clearClasses();
        el = getEL(days[currentDay]);
        el.className += el.className ? ' moveOutRight' : 'moveOutRight';
        rm = getEL(days[currentDay - 1]);
        rm.className += rm.className ? ' moveRight' : 'moveRight';
        currentDay -= 1;
    }
};

var getDates = function() {
    var date, day, datetoday, monthnum;
    date = new Date();
    day = date.getDay();
    datetoday = date.getDate();
    monthnum = date.getMonth();
    getEL('day').innerHTML = weekday[day];
    getEL('date').innerHTML = datetoday + " " + month[monthnum];
};

var getTimes = function() {
    var datTime, hours, minutes, pm;
    datTime = new Date();
    hours = datTime.getHours();
    if (hours >= 12) {
        pm = " pm";
    }
    else{pm = " am";}
    minutes = datTime.getMinutes();
    if (minutes <= 9) {
        minutes = "0" + minutes; //pad minutes with a zero
    }
    if (TwentyFour !== true) {
        hours = ((hours + 11) % 12 + 1);
    }
    if (PadZero) {
        if (hours <= 9) {
            hours = "0" + hours;
        }
    }
    if(settingsObject.am === false){
        getEL('time').innerHTML = hours + ":" + minutes + '<span id="am" class="pm">' + pm + '</span>';
    }
    else{
        getEL('time').innerHTML = hours + ":" + minutes;
    }
    
};

loadc = function(){
   window.location.href = url;
};

var width = window.innerWidth;
if (width == 375) {
    viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', 'width=device-width, initial-scale=1.18, maximum-scale=1.18, user-scalable=0');
} else if (width == 414) {
    viewport = document.querySelector("meta[name=viewport]");
    viewport.setAttribute('content', 'width=device-width, initial-scale=1.3, maximum-scale=1.3, user-scalable=0');
} else {}


var init = function() {
    getDates();
    getTimes();
    setInterval(function() { //update date
        getDates();
    }, 1800000);
    setInterval(function() { //update time
        getTimes();
    }, 20000);
    var lastUpdate = localStorage.getItem('lastUpdate'); //get last update
    if (CT > Number(lastUpdate)) { // if current time is greater than last update plus refresh time
        UW(); //update weather
    } else {
        GW(); // get cached weather
    }
};