#import "kSideViewsLeftListController.h"

@implementation kSideViewsLeftListController
@synthesize sideViews = _sideViews;
@synthesize buddyLockSettings = _buddyLockSettings;
@synthesize dict = _dict;
@synthesize tblView = _tblView;
@synthesize lastIndexPath = _lastIndexPath;
- (id)initForContentSize:(CGSize)contentSize {
	if ((self = [super init])) {
		self.buddyLockSettings = [[[NSMutableDictionary alloc] initWithContentsOfFile:@"/var/mobile/Library/Preferences/com.ba.buddylock.plist"] autorelease];
		UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height - 44)];
		[self setView:view];
		[view release];
		view = nil;
		
		[self setupArrays];
		[self setupLastIndexPath];
		[self setupTableView];
	}
	
	return self;
}
- (id)navigationTitle {
	return @"Left View";
}
- (id)title {
	return @"Left View";
}
- (NSMutableDictionary *)getSideViews {
	NSString *mainPath = @"/Library/BuddyLock/SideViews";
	NSString *appSupportSubpath = @"";
	NSArray *bundlePaths = [[NSFileManager defaultManager] contentsOfDirectoryAtPath:mainPath error:nil];
	NSEnumerator *pathEnum = [bundlePaths objectEnumerator];
	NSString *currPath;
	NSMutableArray *bundles = [NSMutableArray array];
	NSMutableDictionary *plugins = [[NSMutableDictionary alloc] init];
	
	while(currPath = [pathEnum nextObject])
		if ([currPath.pathExtension isEqualToString:@"bundle"])
			[bundles addObject:[mainPath stringByAppendingPathComponent:currPath]];
		
	for (NSString *bundlePath in bundles) {
		NSBundle *bundle = [NSBundle bundleWithPath:bundlePath];
		BOOL success = [bundle load];
		Class PrincipalClass = [bundle principalClass];
		
		if (success) {
			id sideView = [[PrincipalClass alloc] init];
			if (sideView) {
				NSString *identifier = [sideView identifier];
				NSString *name = [sideView name];
				if (identifier && ![identifier isEqualToString:@""] && name && ![name isEqualToString:@""]) {
					[plugins setObject:name forKey:identifier];
				}
			}
			[sideView release];
			sideView = nil;
		}
		
		[bundle unload];
	}
	
	return plugins;
}
- (NSString *)nameForValue:(NSString *)value {
	return [self.dict objectForKey:value];
}
- (NSString *)identifierForName:(NSString *)name {
	return [[self.dict allKeysForObject:name] objectAtIndex:0];
}
- (void)savePreferences {
	[self.buddyLockSettings writeToFile:@"/var/mobile/Library/Preferences/com.ba.buddylock.plist" atomically:YES];
}
- (void)setupArrays {
	self.dict = [self getSideViews];
	self.sideViews = [self.dict allKeys].mutableCopy;
	[self.sideViews insertObject:@"__NONE__" atIndex:0];
	[self.dict setObject:@"None" forKey:@"__NONE__"];
}
- (void)setupLastIndexPath {
	NSIndexPath *indexPath = nil;
	NSString *selected = [self.buddyLockSettings objectForKey:@"kLeftView"];
	for (int i = 0; i < self.sideViews.count; i++) {
		NSString *title = [self.sideViews objectAtIndex:i];
		if ([selected isEqualToString:title]) {
			indexPath = [NSIndexPath indexPathForRow:i inSection:0];
			break;
		}
	}
	if (!indexPath) {
		[self.buddyLockSettings setObject:[self identifierForName:@"__NONE__"] forKey:@"kLeftView"];
		[self savePreferences];
		indexPath = [NSIndexPath indexPathForRow:0 inSection:0];
	}
	
	self.lastIndexPath = indexPath;
}
- (void)setupTableView {
	self.tblView = [[UITableView alloc] initWithFrame:[[self view] frame] style:UITableViewStyleGrouped];
	self.tblView.delegate = self;
	self.tblView.dataSource = self;
	[self.view addSubview:self.tblView];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
	return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
	return self.sideViews.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
	return 40;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
	static NSString *cellIdentifier = @"theCell";
	
	UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
	
	if (!cell) {
		cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier] autorelease];
	}
		
	if ([indexPath compare:self.lastIndexPath] == NSOrderedSame) cell.accessoryType = UITableViewCellAccessoryCheckmark;
	else cell.accessoryType = UITableViewCellAccessoryNone;
	
	NSString *title = [self nameForValue:[self.sideViews objectAtIndex:indexPath.row]];
	
	cell.textLabel.text = title;
	
	return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
	self.lastIndexPath = indexPath;
	UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
	
	[self.buddyLockSettings setObject:[self identifierForName:cell.textLabel.text] forKey:@"kLeftView"];
	[self savePreferences];
	
	[tableView reloadData];
}

- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section {
	return @"Side Views";
}

- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section {
    return @"Facebook, Twitter, & Do Not Disturb will not work on firmwares prior to iOS 6.";
}

- (void)dealloc {
	if (self.tblView) {
		[self.tblView release];
		self.tblView = nil;
	}
	
	if (self.sideViews) {
		[self.sideViews release];
		self.sideViews = nil;
	}
	
	if (self.dict) {
		[self.dict release];
		self.dict = nil;
	}
	
	self.lastIndexPath = nil;
	
	[super dealloc];
}

@end