Here is my latest and long awaited theme Cursi.
SPECIAL thanks to my private testers and those that donated.

Also thanks to Jon, Saleeh, Elias, and Dustin for their inspiration, resources, and help.
I hope you guys enjoy this new release. Thank you.

If you wish to DONATE you can do so at: ocgonz@gmail.com
Thanks again. Enjoy!