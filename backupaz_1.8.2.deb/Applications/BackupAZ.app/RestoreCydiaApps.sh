#!/bin/bash
killall MobileCydia
wait
apt-get update
wait
dpkg --set-selections < /var/mobile/Library/Preferences/BackupAZ/CydiaPackages/installed-packages.txt
wait
apt-get -y --allow-unauthenticated dselect-upgrade
