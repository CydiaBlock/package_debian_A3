#!/bin/bash
dpkg --get-selections > /var/mobile/Library/Preferences/BackupAZ/CydiaPackages/installed-packages.txt