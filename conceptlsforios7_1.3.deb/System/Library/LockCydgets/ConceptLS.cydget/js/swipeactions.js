
var pressedLT="0";
  function slideout(){

  pressedLT++
    if(pressedLT===1){
$('#leftpanel').addClass('go');
$('#wallpaperclone4').addClass('go');
$('#topbar').css('z-index','0');
$('#lefttouch').css('left','85px');
$('#lefttouch').css('top','260px');
$("#lefttouch").css({"-webkit-transform":"rotate(180deg)"});


$('#righttouch').css('left','300px');
$('#righttouch').css('top','260px');
$("#righttouch").css({"-webkit-transform":"rotate(0deg)"});

turnoff();
    }

    if(pressedLT===2){
$('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('#topbar').css('z-index','4');
$('#lefttouch').css('left','0px');
$('#lefttouch').css('top','259px');
$("#lefttouch").css({"-webkit-transform":"rotate(0deg)"});
$('.options').css('display','block');
$('.options2').css('display','none');

pressedLT="0";
    }
    
    
  }


  var pressedRT="0";
  function slideoutright(){

    pressedRT++

    
    if(pressedRT===1){
$('#topbar').css('z-index','0');
$('#righttouch').css('left','125px');
$('#righttouch').css('top','260px');
$("#righttouch").css({"-webkit-transform":"rotate(180deg)"});

animate();
$('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('#lefttouch').css('left','0px');
$('#lefttouch').css('top','259px');
$("#lefttouch").css({"-webkit-transform":"rotate(0deg)"});


    }

    if(pressedRT===2){
  $('#topbar').css('z-index','4');

turnoff();
$('#righttouch').css('left','300px');
$('#righttouch').css('top','259px');
$("#righttouch").css({"-webkit-transform":"rotate(0deg)"});
pressedRT="0";
    }
    
    
  }


  function anitop(){
$('.backshelf').addClass('go');
$('#wallpaperclone3').addClass('go');
$('.fulltime').addClass('go');
$('#tempimg').addClass('on');
$('.desc').addClass('on');
$('.temptoday').addClass('on');
$('.TodayIcon2').addClass('on');
$('.extendeddesc').addClass('ani');
$('#topdesc').addClass('on');
$('#hilo').css('display','block');
$('#wallpaperclone3').css('display','block');
}



 function anibottom(){
      $('.backshelf').removeClass('go');
$('#wallpaperclone3').removeClass('go');
$('.fulltime').removeClass('go');
$('.TodayIcon2').removeClass('on');
$('.extendeddesc').removeClass('ani');
$('#tempimg').removeClass('on');
$('.desc').removeClass('on');
$('.temptoday').removeClass('on');
$('#hilo').css('display','none');


  }


$('#leftswipe').bind('swiperight', function (e) {

});

function leftout(){
$('#leftpanel').addClass('go');
$('#wallpaperclone4').addClass('go');
$('#topbar').css('z-index','0');
$('#lefttouch').css('left','85px');
$('#lefttouch').css('top','260px');
$("#lefttouch").css({"-webkit-transform":"rotate(180deg)"});
;

$('#righttouch').css('left','300px');
$('#righttouch').css('top','260px');
$("#righttouch").css({"-webkit-transform":"rotate(0deg)"});

turnoff();
}

function leftin(){
  $('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('#topbar').css('z-index','4');
$('#lefttouch').css('left','0px');
$('#lefttouch').css('top','258px');
$("#lefttouch").css({"-webkit-transform":"rotate(0deg)"});
$('.options').css('display','block');
$('.options2').css('display','none');
}




function rightout(){
$('#topbar').css('z-index','0');
$('#righttouch').css('left','125px');
$('#righttouch').css('top','260px');
$("#righttouch").css({"-webkit-transform":"rotate(180deg)"});
animate();
$('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('#lefttouch').css('left','0px');
$('#lefttouch').css('top','259px');
$("#lefttouch").css({"-webkit-transform":"rotate(0deg)"});
}


function rightin(){
    $('#topbar').css('z-index','4');
$('#righttouch').css('left','300px');
$('#righttouch').css('top','260px');
$("#righttouch").css({"-webkit-transform":"rotate(0deg)"});

turnoff();
}



function animate(){
$('#lockedge').addClass('on')
$('#locker').addClass('on');
$('.icons').addClass('on');
$('#circle').addClass('on');
$('#wallpaperclone').css('left','10px');

}
function turnoff(){
$('#lockedge').removeClass('on')
$('#locker').removeClass('on');
$('.icons').removeClass('on');
$('#circle').removeClass('on');
$('#wallpaperclone').css('left','900px');
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
}






//$('#locker').bind('taphold', function (e) {
  //dimtime = prompt("Enter seconds to dim. Max 25","");
  //dimtime = dimtime;
  //localStorage.setItem('dimtime', dimtime);
  //var saved1 = localStorage.getItem('dimtime'); 
//controldim(saved1);
//});

  
       
//dimming=localStorage.getItem('dimtime'); 
//if(dimming!=null){
 //   time=dimming;
  //  setTimeout(function(){controldim(time)}, 1000);

//}
 




$('#message').bind('taphold', function (e) {
changeicon("message");
$('#menuholder').css('display','block');
});
$('#email').bind('taphold', function (e) {
changeicon("email");
$('#menuholder').css('display','block');
});
$('#unlock').bind('taphold', function (e) {
changeicon("unlock");
$('#menuholder').css('display','block');
});

$('.chooseicon').bind('swipeup', function (e) {
$('.chooseicon').css('left','400px');
$('.chooseicon2').css('left','0px');
$('.chooseicon2').css('left','40px');

});
$('.chooseicon2').bind('swipedown', function (e) {
$('.chooseicon').css('left','0px');
$('.chooseicon').css('left','40px');
$('.chooseicon2').css('left','400px');

});


