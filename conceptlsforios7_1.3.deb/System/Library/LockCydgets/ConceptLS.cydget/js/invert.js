
count="0";
isdark=localStorage.getItem('darklight');
  if(isdark=="dark"){darklight();}

function darklight(){
  count++
if(count=="1"){localStorage.setItem('darklight','dark');makedark();
var changed="Light";
document.getElementById("option6").innerHTML = '<span>' + (changed) + '</span>'



}
if(count=="2"){localStorage.setItem('darklight','light');makelight();count="0";
var changed="Dark";
document.getElementById("option6").innerHTML = '<span>' + (changed) + '</span>'
}
}



function makedark(){
var css = {
webkitFilter: 'invert(100%)',
};
$('#unlockbutton').css(css);
$('#locker').css(css);
$('#lockedge').css(css);
$('.icons').css(css);
$('#menuholder').css(css);
$('.weatherdata').css(css);
$('.extendeddesc').css(css);
$('.fulltime').css(css);
$('#tempimg').css(css);
$('#todayicon').css(css);
$('.temptoday').css(css);
$('.desc').css(css);




$('#option1,#option2,#option3,#option4,#option5,#option6,#option7,#option8,#option9,#lefttouch,#righttouch').css('color','black');
$('#locker1,#locker2,#locker3,#locker4,#locker5,#locker6,#closelocker').css('color','black');


$('#messages,#tweetbot,#emails,#appstore,#calendar,#pandora,#facebook,#instagram,#maps,#music').css('color','black');
}

function makelight(){
var css2 = {
webkitFilter: 'invert(0%)',

};
$('#locker').css(css2);
$('#unlockbutton').css(css2);
$('.icons').css(css2);
$('#lockedge').css(css2);
$('#menuholder').css(css2);
$('#topbar').css(css2);
$('.weatherdata').css(css2);
$('.extendeddesc').css(css2);
$('.fulltime').css(css2);
$('#tempimg').css(css2);
$('#todayicon').css(css2);
$('.temptoday').css(css2);
$('.desc').css(css2);



$('#option1,#option2,#option3,#option4,#option5,#option6,#option7,#option8,#option9,#lefttouch,#righttouch').css('color','white');
$('#locker1,#locker2,#locker3,#locker4,#locker5,#locker6,#closelocker').css('color','white');


$('#messages,#tweetbot,#emails,#appstore,#calendar,#pandora,#facebook,#instagram,#maps,#music').css('color','white');


}

