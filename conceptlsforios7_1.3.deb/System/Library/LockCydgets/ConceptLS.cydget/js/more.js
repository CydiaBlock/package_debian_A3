lockbutton=localStorage.getItem('unlockbutton');


if(lockbutton=="0"){locker0();}
if(lockbutton=="1"){locker1();}
if(lockbutton=="2"){locker2();}
if(lockbutton=="3"){locker3();}
if(lockbutton=="4"){locker4();}
if(lockbutton=="5"){locker5();}
if(lockbutton=="6"){locker6();}


var unlocker="1";
function unlockers(){
unlocker++
if(unlocker=="1"){locker0();}
  else{unlocker="0";locker1();}
}

function locker0(){
  width="100";
  src="img/nolocker.png"
 document.getElementById("unlockbutton").innerHTML = '<img width='+width+' src='+src+'>'
 locker="0";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}

function more(){
$('.options').css('display','none');
$('.options2').css('display','block');
}

function unlockbutton(){
$('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('#topbar').css('z-index','4');
$('#lefttouch').css('left','0px');
$('#lefttouch').css('top','259px');
$("#lefttouch").css({"-webkit-transform":"rotate(0deg)"});

chooseunlockbutton();
}

function chooseunlockbutton(){
  $('.unlockselectbackground').css('display','block');
}


function locker1(){
  width="100";
  src="img/locker.png"
 document.getElementById("unlockbutton").innerHTML = '<img width='+width+' src='+src+'>'
 locker="1";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}

function locker2(){
  width="100";
  src="img/lockersquare.png"
 document.getElementById("unlockbutton").innerHTML = '<img width='+width+' src='+src+'>'
 locker="2";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}

function locker3(){
  width="100";
  src="img/lockerpadlock.png"
 document.getElementById("unlockbutton").innerHTML = '<img width='+width+' src='+src+'>'
 locker="3";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}

function locker4(){
  width="100";
  src="img/lockersimple.png"
 document.getElementById("unlockbutton").innerHTML = '<img width='+width+' src='+src+'>'
 locker="4";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}

function locker5(){
  width="100";
  src="img/lockerkey.png"
 document.getElementById("unlockbutton").innerHTML = '<img width='+width+' src='+src+'>'
 locker="5";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}


function lockertext(){
if(confirm('Use previous text?')){
locker6();
}

else{  localStorage.removeItem('usertext'); locker6();}
}

function locker6(){
 var usertext = localStorage.getItem('usertext');
 if(usertext==null){
  usertext = prompt("Enter Text","");
  usertext = usertext;
  localStorage.setItem('usertext', usertext);
 }

 document.getElementById("unlockbutton").innerHTML = '<span>' + (usertext) + '</span>'

$('#unlockbutton').css('width','320px');
$('#unlockbutton').css('text-align','center');
$('#unlockbutton').css('left','0px');
$('#unlockbutton').css('top','480px');


 locker="6";
 localStorage.setItem('unlockbutton',locker);
closelocker();
}

function closelocker(){
  $('.unlockselectbackground').css('display','none');
}