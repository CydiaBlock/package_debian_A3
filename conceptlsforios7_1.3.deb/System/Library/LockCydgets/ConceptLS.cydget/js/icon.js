
    $("#locker").draggable({
         containment: "#lockercontainer",
          scroll: false,
        stop: function (event, ui) {
          var topc = ui.position.top; 
          var leftc = ui.position.left;
          if(topc<"150"){ $("#locker").css('left','200px');
      $("#locker").css('top','220px');}
      if(leftc<"120"){  $("#locker").css('left','200px');
      $("#locker").css('top','220px');}
      if(topc>"300"){ $("#locker").css('left','200px');
      $("#locker").css('top','220px');}

        
        },
        drag: function (event, ui) { //messages
          var topc = ui.position.top; 
          var leftc = ui.position.left;

          if(topc>"300"){bottomicon();}
          if(topc<"150"){topicon();}
          if(leftc<"120"){middleicon();}  
        }
    });


function bottomicon(){
url=localStorage.getItem('URJ');
if(url==null){
  url="com.apple.Music";
}
openapp(url);
}

function topicon(){
url=localStorage.getItem('URI');
if(url==null){
  url="com.apple.MobileSMS"
}
openapp(url);
}

function middleicon(){
url=localStorage.getItem('URK');
if(url==null){
  url="com.apple.mobilemail"
}
openapp(url);
}






function changeicon(name){
  $('#wallpaperclone2').css('left','0px')
  $('.chooseicon').css('left','40px');
  if(name=="message"){
  localStorage.setItem('icon',name);
  localStorage.setItem(name, name);
}
  if(name=="unlock"){
  localStorage.setItem('icon',name);
  localStorage.setItem(name, name);
}
  if(name=="email"){
  localStorage.setItem('icon',name);
  localStorage.setItem(name, name);
}

}

function tweetbot(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#menuholder').css('display','none');
$('#wallpaperclone2').css('left','500px');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/tweetbot.png)');
  localStorage.setItem(icon, self);
  url="com.tapbots.Tweetbot3";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}

function emails(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/email.png)');
  localStorage.setItem(icon, self);
  url="com.apple.mobilemail";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}


function messages(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/message.png)');
  localStorage.setItem(icon, self);
  url="com.apple.MobileSMS";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}

function appstore(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/appstore.png)');
  localStorage.setItem(icon, self);
  url="com.apple.AppStore";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}

function calendar(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/calendar.png)');
  localStorage.setItem(icon, self);
  url="com.apple.mobilecal";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}
function facebook(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/facebook.png)');
  localStorage.setItem(icon, self);
  url="com.facebook.Facebook";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}
function pandora(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/pandora.png)');
  localStorage.setItem(icon, self);
  url="com.apple.Pandora";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}
function instagram(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/instagram.png)');
  localStorage.setItem(icon, self);
  url="com.burbn.instagram";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}function maps(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/maps.png)');
  localStorage.setItem(icon, self);
  url="com.apple.Maps";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}
function music(self){
$('.chooseicon').css('left','500px');
$('.chooseicon2').css('left','500px');
$('#wallpaperclone2').css('left','500px');
$('#menuholder').css('display','none');
  icon = localStorage.getItem('icon');
  $('#'+icon).css('background-image', 'url(img/music.png)');
  localStorage.setItem(icon, self);
  url="com.apple.Music";
  if(icon=="message"){
localStorage.setItem('URI',url);
  }
    if(icon=="unlock"){
localStorage.setItem('URJ',url);
  }
    if(icon=="email"){
localStorage.setItem('URK',url);
  }
}



newmessage=localStorage.getItem('message');
newunlock=localStorage.getItem('unlock');
newemail=localStorage.getItem('email');




if(newmessage!=null){
$('#message').css('background-image', 'url(img/'+newmessage+'.png)');
}
if(newunlock!=null){
$('#unlock').css('background-image', 'url(img/'+newunlock+'.png)');
}
if(newemail!=null){
$('#email').css('background-image', 'url(img/'+newemail+'.png)');
}

