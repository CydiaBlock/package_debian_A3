  function bg(){
      buttonpress();
$('#files').css('display','block');
$('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('.fulltime').removeClass('on');
  }

  function zipcode(){
     code = prompt("Enter your code","");
     localStorage.setItem('sCityCodes', code);
     var saved = localStorage.getItem('sCityCodes'); 
     location.reload();
  }

  function celcius(){
    code = prompt("Do you want celcius? Type yes or no","");
    if(code =="no"){code ="s";}
      if(code =="yes"){code ="m";}

     localStorage.setItem('sUnit', code);
     var saved1 = localStorage.getItem('sUnit'); 
     location.reload();
  }

  function hrchange(){
    code = prompt("Do you want 24hr? Type yes or no","");
    if(code =="no"){code ="false";}
      if(code =="yes"){code ="true";}
     localStorage.setItem('TwentyFourHourClock', code);
     var saved2 = localStorage.getItem('TwentyFourHourClock'); 
     location.reload();
  }

  function reset(){
    localStorage.clear();
    location.reload();
  }

  
function help(){
$('#leftpanel').removeClass('go');
$('#wallpaperclone4').removeClass('go');
$('#topbar').css('z-index','4');
$('#lefttouch').css('left','0px');
$("#wallpaper").css({"-webkit-filter":"blur(5px)"});

    $('#helpscreen').css('z-index','30');
    $('#morehelp').css('z-index','35');
    $('#helpscreen').css('opacity','1');
    $('#morehelp').css('opacity','1');

}

function morehelp(){
    $('#helpscreen').css('z-index','0');
    $('#helpscreen2').css('z-index','35');
    $('#morehelp').css('z-index','0');
    $('#helpscreen').css('opacity','0');
    $('#helpscreen2').css('opacity','1');
    

}

function closehelp(){
  $("#wallpaper").css({"-webkit-filter":"blur(0px)"});
    $('#helpscreen').css('z-index','0');
    $('#morehelp').css('z-index','0');
    $('#helpscreen2').css('z-index','0');
    $('#morehelp').css('opacity','0');
    $('#helpscreen2').css('opacity','0');

}
