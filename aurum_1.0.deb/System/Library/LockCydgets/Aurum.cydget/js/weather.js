//var sCityCodes = "29072"; 
//var sUnit = "s";  // m for celcius 
var sCityNames = "";
//var sCityCodes = "29072"; //weather code. Find from weather.com look in url.
//var bgColor="whiteblack";
var refresh = 30 * 60 * 10000; //refresh in milliseconds (default: 1500 sec.)

if(sCityCodes==null){alert("set settings in the settings app");
var sCityCodes = "38671"; 
var sUnit = "s";  // m for celcius 
}



var aCityNames = sCityNames.split('|');
var aCityCodes = sCityCodes.split('|');
var code = aCityCodes[0];
var language = window.navigator.language;

//localize languages
var web = { i18n: {
		locale: {},
		getLocale: function(lng){
			var l = (lng)?lng: window.navigator.language;
	    //alert('Your language is' + " " + l ); //Loop
			$(function(d) {
		web.i18n.locale = d;
				}).error(function() {
					web.i18n.getLocale('en_US'); //incase. default
				});
		},
		getMessage: function(t){
			return (this.locale[t])?this.locale[t].message: t;
		}
	}
};
web.i18n.getLocale();


//alert("t")

//return text from language clean

function thislangText(t) {
    t = t.replace(/[\/]/g, "_____");
    t = t.replace(/-/g, "____");
    t = t.replace(/ \/ /g, "___");
    t = t.replace(/ /g, "_");
    t = t.replace("____", "");	
    return web.i18n.getMessage(t);
}


String.prototype.t = function() {
    var str;
    if (thislangText(this) !== "") {
	str = thislangText(this);
    } else {
	str = this;
    }
    return str;
};


// get weather //

function GetXmlFeed(wData) {
  
    
    bwData = wData;
    var lang = (typeof language == "string")?language.replace(/-/g, "_"):language;
    var sc = document.createElement("script");
    sc.src='http://wxdata.weather.com/wxdata/mobile/mobagg/' + code + '.js?key=e88d1560-a740-102c-bafd-001321203584&units=' + sUnit + '&locale=' + lang + '&cb=XmlFeedCB';
	document.body.appendChild(sc);


}

function XmlFeedCB(jsonP){
	json = jsonP[0];
	ShowContent(bwData);
    
    setTimeout(function() {
	GetXmlFeed(false);
    }, refresh);
}



   

function Showdata() {
var days = json.DailyForecasts;
var hours = json.HourlyForecasts;
 
var currentTime = new Date().getHours();

h = currentTime;

if (h < 0) {x=0;}
if (h < 2) {x=1;}
if (h < 4) {x=2;}
if (h < 6) {x=3;}
if (h < 8) {x=4;}
if (h < 10) {x=5;}
if (h < 12) {x=6;}
if (h < 14) {x=7;}
if (h < 16) {x=8;}
if (h < 14) {x=9;}
if (h < 20) {x=10;}
if (h < 22) {x=11;}
if (h < 25) {x=12;}

//alert(h);

   //alert( hours[x].temp); hourly temp
   var hd = hours[1].temp;

   //alert(hd); //24 hours
   //alert(JSON.stringify(json.DailyForecasts));


hd=json.StandardObservation.temp;




 var html = [];
    


    for (i = 0; i < days.length; i++) {
      
		if (i > weatherSettings.days-1) break;

	html.push('<div id="item">');
	var dn = days[i].day ? days[i].day : days[i].night; //days
   
	var d = new Date(parseInt(days[i].validDate,10) * 1000); //date
	var weekdays = d;
	//alert(d); //days
	html.push('<div id="date">');
	html.push('<span id="weekday">' + ('' + weekdays) + '</span> <span id="days">' + d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + '</span>');
	html.push('</div>');
     //alert(html)
	//icon
	html.push('<div id="icon">');
	html.push('  <img id="weatherIcon" width="40" src="img/LSicons/' + dn.icon + '_small' + '.png"	title="' + dn.phrase + '"/>');	//title is weather condition
	//alert(dn.icon);
	html.push('</div>');

	//temp
	html.push('<div id="temp"><span id="temp-max">'  + (days[i].maxTemp  ? (days[i].maxTemp + '') : '--') +'</span> <span id="temp-min">  ' + (days[i].minTemp+'' ? (days[i].minTemp + '') : '--') +'</span></div>');
	//alert(days[i].maxTemp);
       //alert(days[1].day);
	var b = 0;

	if(days[i].maxTemp == undefined){
	   var fix = days[i].maxTemp;
	b=1;
	b++
}
	if(b==2){
	    //alert(fix);
	fix = "NA";   
	b = 0;
    }
	//precip
	html.push('<div id="precip">' + dn.pop + '% ' + web.i18n.getMessage("precip") + '</div>');

	//wind
	html.push('<div id="wind">' + dn.wDirText.t() + '<br/>' + dn.wSpeed + ((sUnit == 's') ? 'mph' : 'km/h') + '</div>');	
    }
	//city
	html.push('<div id="city">' + json.Location.city + '</div>');
	//desc
	html.push('<div id="desc">' + json.HiradObservation.text + '</div>');


	html.push('<div id="shortdesc">' + dn.bluntPhrase + '</div>');


	html.push('<div id="humidity">' +"Humid"+":" + " " +dn.humid +	'</div>');

	html.push('<div id="lat">' + json.Location.lat + '</div>');

	html.push('<div id="long">' + json.Location.lng + '</div>');
     
html.push('<div id="realfeel">'+"Feels Like " + json.StandardObservation.feelsLike + '\&#176 '+ '</div>');
     
	html.push('<div id="temptoday">' + hd + '\&#176 '+ '</div>');

	html.push('<div id="temptoday2">' + hd + '\&#176 '+ '</div>');

  html.push('  <img id="TodayIcon" width="135" src="img/LSicons/' + json.StandardObservation.wxIcon +  '_small' + '.png"  title="' + dn.phrase + '"/>');  //title is weather condition
	//alert(dn.icon);
	html.push('</div>');
   //alert(json.StandardObservation.wxIcon)
$('.weatherdata #weather').html(html.join(''));


}



function ShowContent(wData) {
    Showdata();
     Showdatanext();

  
  if (wData) {
	$('.weatherdata').hide().fadeIn(3000);
    }
}


(function($){

//extend to adj in html
$.fn.weather = function(options){
		weatherSettings = $.extend({
								"locationName": "",
								"locationCode":"",
								"showall": true,
								"days": 4}, options); //change from html

			GetXmlFeed(true);}
})($);

